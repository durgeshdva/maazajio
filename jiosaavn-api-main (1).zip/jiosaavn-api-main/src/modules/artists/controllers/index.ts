export * from './artist.controller'
